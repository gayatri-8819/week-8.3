JavaFX Tip Calculator (FXML)

Files:
- TipCalculatorApp.java
- TipCalculatorController.java
- tip_calculator.fxml

Keep all three files in the same source folder/package (the default package in this example).

Features:
- Accepts bill amount and tip percentage.
- Calculates and displays the tip to 2 decimal places.
- Shows an error for non-numeric or negative input.
- Reset clears both fields and messages.

JavaFX setup:
You need a JDK and JavaFX SDK. If JavaFX is not configured in your IDE,
set the JavaFX SDK's lib folder as the module path and add javafx.controls,javafx.fxml.

Example command (Windows; change the path to your JavaFX SDK):
javac --module-path "C:\javafx-sdk\lib" --add-modules javafx.controls,javafx.fxml TipCalculatorApp.java TipCalculatorController.java
java --module-path "C:\javafx-sdk\lib" --add-modules javafx.controls,javafx.fxml TipCalculatorApp

Put tip_calculator.fxml in the runtime classpath/source folder so
getResource("tip_calculator.fxml") can find it.
